//
//  Image.swift
//  
//
//  Created by lss8 on 15/04/23.
//

/*
 In here i created an extension of the Image class, and defined two structures, Icons and Puppies.
 And "pre-coded" the Image call i would have to make if I wanted to use one of them. (The Color extension works similary)
 
 So when i want to access an image I can just type
 
 Image.icon.imageName
 
 instead of having to call
 
 Image("imageName") all the time
 
 But it is no means mandatory to our architectury, so feel free to use what you like the most :)
 
 */

import Foundation
import SwiftUI

extension Image {
    static let icon = Icons()
    static let puppy = Puppies()
}

struct Icons {
    
    let logo = Image("logo")
    let popUp = Image("popUp")
    
    let quizButton = Image("quizBreedButton")
    let wrongQuizButton = Image("wrongQuizBreedButton")
    
    let heart = Image("heart")
    let heartBlank = Image("heartBlank")
    
}

struct Puppies {
    let australianShepperd = Image("australianShepperd")
    let boxer = Image("boxer")
    let dachshund = Image("dachshund")
    let frenchBulldog = Image("frenchBulldog")
    let goldenRetriever = Image("goldenRetriever")
    let husky = Image("husky")
    let rottweiler = Image("rottweiler")
    let samoyed = Image("samoyed")
    let shitzu = Image("shitzu")
    let yorkshire = Image("yorkshire")
}
